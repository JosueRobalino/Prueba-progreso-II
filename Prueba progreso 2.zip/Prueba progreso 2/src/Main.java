import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class Parqueadero1 {
    private double tarifaPorMinuto;
    private static int horaActual;
    private static int minutoActual;
    private Map<Integer, Carro> puestos;
    private double ingresos;

    public Parqueadero1(double tarifaPorMinuto, int horaInicial, int minutoInicial) {
        this.tarifaPorMinuto = tarifaPorMinuto;
        this.horaActual = horaInicial;
        this.minutoActual = minutoInicial;
        this.puestos = new HashMap<>();
        for (int i = 1; i <= 3; i++) {
            puestos.put(i, null);
        }
        this.ingresos = 0.0;
    }

    public void ingresarCarro(String placa, int horaEntrada, int minutoEntrada, Usuario usuario) {
        if (horaEntrada < 8 || (horaEntrada == 18 && minutoEntrada > 0) || horaEntrada > 18) {
            System.out.println("El parqueadero está cerrado en esa hora.");
            return;
        }

        for (Carro carro : puestos.values()) {
            if (carro != null && carro.getPlaca().equals(placa)) {
                System.out.println("Un carro con esa placa ya está en el parqueadero.");
                return;
            }
        }

        for (Map.Entry<Integer, Carro> entry : puestos.entrySet()) {
            if (entry.getValue() == null) {
                puestos.put(entry.getKey(), new Carro(placa, horaEntrada, minutoEntrada, usuario));
                System.out.println("Carro con placa " + placa + " ingresado en el puesto " + entry.getKey() + " a las " + horaEntrada + ":" + String.format("%02d", minutoEntrada) + " por " + usuario.getNombre() + ".");
                return;
            }
        }

        System.out.println("No hay puestos disponibles.");
    }

    public void darSalidaCarro(String placa, int horaSalida, int minutoSalida, Usuario usuario) {
        if (horaSalida < 8 || (horaSalida == 18 && minutoSalida > 0) || horaSalida > 18) {
            System.out.println("El parqueadero está cerrado en esa hora.");
            return;
        }

        for (Map.Entry<Integer, Carro> entry : puestos.entrySet()) {
            Carro carro = entry.getValue();
            if (carro != null && carro.getPlaca().equals(placa)) {
                int tiempoEnMinutos = (horaSalida * 60 + minutoSalida) - (carro.getHoraEntrada() * 60 + carro.getMinutoEntrada());
                if (tiempoEnMinutos <= 0) {
                    System.out.println("La hora de salida debe ser mayor a la hora de entrada.");
                    return;
                }
                double costo = tiempoEnMinutos * tarifaPorMinuto;
                ingresos += costo;
                puestos.put(entry.getKey(), null);
                System.out.println("Carro con placa " + placa + " ha salido del puesto " + entry.getKey() + " a las " + horaSalida + ":" + String.format("%02d", minutoSalida) + ". Costo: $" + String.format("%.2f", costo) + ". Salida realizada por " + usuario.getNombre() + ".");
                return;
            }
        }

        System.out.println("Carro no encontrado en el parqueadero.");
    }

    public void consultarIngresos() {
        System.out.println("Ingresos totales del parqueadero: $" + String.format("%.2f", ingresos));
    }

    public void puestosDisponibles() {
        int disponibles = 0;
        for (Carro carro : puestos.values()) {
            if (carro == null) {
                disponibles++;
            }
        }
        System.out.println("Puestos disponibles: " + disponibles);
    }

    public void avanzarReloj(int horas, int minutos) {
        int nuevaHora = horaActual + horas;
        int nuevosMinutos = minutoActual + minutos;
        nuevaHora += nuevosMinutos / 60;
        nuevosMinutos = nuevosMinutos % 60;

        if (nuevaHora >= 18 || (nuevaHora == 18 && nuevosMinutos > 0)) {
            System.out.println("No se puede avanzar el reloj más allá de las 18:00.");
        } else {
            horaActual = nuevaHora;
            minutoActual = nuevosMinutos;
            System.out.println("La hora actual del parqueadero es " + horaActual + ":" + String.format("%02d", minutoActual) + ".");
        }
    }

    public void cambiarTarifa(double nuevaTarifaPorMinuto) {
        this.tarifaPorMinuto = nuevaTarifaPorMinuto;
        System.out.println("Tarifa del parqueadero cambiada a $" + String.format("%.2f", nuevaTarifaPorMinuto) + " por minuto.");
    }

    class Carro {
        private String placa;
        private int horaEntrada;
        private int minutoEntrada;
        private Usuario usuario;

        public Carro(String placa, int horaEntrada, int minutoEntrada, Usuario usuario) {
            this.placa = placa;
            this.horaEntrada = horaEntrada;
            this.minutoEntrada = minutoEntrada;
            this.usuario = usuario;
        }

        public String getPlaca() {
            return placa;
        }

        public int getHoraEntrada() {
            return horaEntrada;
        }

        public int getMinutoEntrada() {
            return minutoEntrada;
        }

        public Usuario getUsuario() {
            return usuario;
        }
    }

    static class Usuario {


        private String nombre;

        public Usuario(String nombre) {
            this.nombre = nombre;
        }

        public String getNombre() {
            return nombre;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese la tarifa inicial del parqueadero (por minuto): ");
        double tarifaInicialPorMinuto = scanner.nextDouble();

        System.out.print("Ingrese la hora inicial del parqueadero (0-23): ");
        horaActual = scanner.nextInt();

        System.out.print("Ingrese los minutos iniciales del parqueadero (0-59): ");
        minutoActual = scanner.nextInt();

        Parqueadero1 parqueadero1 = new Parqueadero1(tarifaInicialPorMinuto, horaActual, minutoActual);

        while (true) {
            System.out.println("\n1. Ingresar carro");
            System.out.println("2. Dar salida a carro");
            System.out.println("3. Consultar ingresos");
            System.out.println("4. Consultar puestos disponibles");
            System.out.println("5. Avanzar reloj");
            System.out.println("6. Cambiar tarifa");
            System.out.println("7. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del usuario: ");
                    scanner.nextLine();  // Consume newline
                    String nombreUsuarioIngreso = scanner.nextLine();
                    Usuario usuarioIngreso = new Usuario(nombreUsuarioIngreso);

                    System.out.print("Ingrese la placa del carro: ");
                    String placaIngreso = scanner.next();
                    //System.out.print("Ingrese la hora de entrada (0-23): ");
                    int horaEntrada = horaActual;
                    //System.out.print("Ingrese los minutos de entrada (0-59): ");
                    int minutoEntrada = minutoActual;
                    parqueadero1.ingresarCarro(placaIngreso, horaEntrada, minutoEntrada, usuarioIngreso);
                    break;

                case 2:
                    System.out.print("Ingrese el nombre del usuario: ");
                    scanner.nextLine();  // Consume newline
                    String nombreUsuarioSalida = scanner.nextLine();
                    Usuario usuarioSalida = new Usuario(nombreUsuarioSalida);

                    System.out.print("Ingrese la placa del carro: ");
                    String placaSalida = scanner.next();
                    //System.out.print("Ingrese la hora de salida (0-23): ");
                    int horaSalida = horaActual;
                    //System.out.print("Ingrese los minutos de salida (0-59): ");
                    int minutoSalida = minutoActual;
                    parqueadero1.darSalidaCarro(placaSalida, horaSalida, minutoSalida, usuarioSalida);
                    break;

                case 3:
                    parqueadero1.consultarIngresos();
                    break;

                case 4:
                    parqueadero1.puestosDisponibles();
                    break;

                case 5:
                    System.out.print("Ingrese las horas a avanzar: ");
                    horaActual = scanner.nextInt();
                    System.out.print("Ingrese los minutos a avanzar: ");
                    minutoActual = scanner.nextInt();
                    parqueadero1.avanzarReloj(horaActual, minutoActual);
                    break;

                case 6:
                    System.out.print("Ingrese la nueva tarifa (por minuto): ");
                    double nuevaTarifaPorMinuto = scanner.nextDouble();
                    parqueadero1.cambiarTarifa(nuevaTarifaPorMinuto);
                    break;

                case 7:
                    System.out.println("Saliendo del sistema.");
                    scanner.close();
                    return;

                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        }
    }
}
